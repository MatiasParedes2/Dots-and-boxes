#include<iostream>
#include<vector>
using namespace std;
class disfrazes_precio{
int  disfraz1=22;
int  disfraz2=33;
int  disfraz3=49;
int  disfraz4=30;
int  disfraz5=15;
int cantidad=0;

public:
    disfrazes_precio(){int disfraz1, disfraz2, disfraz3, disfraz4,disfraz5,cantidad;}
    disfrazes_precio(int _disfraz1,int _disfraz2,int _disfraz3,int _disfraz4,int _disfraz5,int _cantidad):disfraz1(_disfraz1),disfraz2(_disfraz2),disfraz3(_disfraz3),disfraz4(_disfraz4),disfraz5(_disfraz5),cantidad(_cantidad){}

    int get_precio1(){return disfraz1;}
    int get_precio2(){return disfraz2;}
    int get_precio3(){return disfraz3;}
    int get_precio4(){return disfraz4;}
    int get_precio5(){return disfraz5;}

    void set_cantidad(int _cantidad){cantidad=_cantidad;}
    


    ~disfrazes_precio(){cout<<"Sin stock disponible"<<endl;}
};