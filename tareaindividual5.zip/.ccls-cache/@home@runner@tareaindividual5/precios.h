
#include<iostream>
#include "disfraces.h"
using namespace std;


class Resultado : public Disfraces{
private:
  int antiguo;
public:
  Resultado(int,int);
  void mostrar_resultado();
};

Disfraces::Disfraces(int _cantidad){
  cantidad=_cantidad;
}
Resultado::Resultado(int _cantidad, int _antiguo) : Disfraces(_cantidad){
  antiguo=_antiguo;
}
void Resultado::mostrar_resultado(){
  enseñar_cantidad_de_disfrases();
  srand(time(NULL));
  int a=1+rand()%5;
  double decimal_cantidad=cantidad%5;
  int cantidad_int=cantidad/5;
  
  float costo1=0,c_1=0,c_2=0,c_3=0,c_4=0,c_5=0,descuento=0;
  
  if(antiguo==1){
    if(a==1){
      if(decimal_cantidad==1){
        descuento=20/4;
        c_1= (20-descuento)*(cantidad_int+1);
        c_2=30*cantidad_int;
        c_3=25*cantidad_int;
        c_4=35*cantidad_int;
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;  
        cout<<"Se aplico el descuento del disfras del Fantasma"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(decimal_cantidad==2){
        descuento=20/4;
        c_1= (20-descuento)*(cantidad_int+1);
        c_2=30*(cantidad_int+1);
        c_3=25*cantidad_int;
        c_4=35*cantidad_int;
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;  
        cout<<"Se aplico el descuento del disfras del Fantasma"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(decimal_cantidad==3){
        descuento=20/4;
        c_1= (20-descuento)*(cantidad_int+1);
        c_2=30*(cantidad_int+1);
        c_3=25*(cantidad_int+1);
        c_4=35*cantidad_int;
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5; 
        cout<<"Se aplico el descuento del disfras del Fantasma"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(decimal_cantidad==4){
       descuento=20/4;
       c_1= (20-descuento)*(cantidad_int+1);
       c_2=30*(cantidad_int+1);
       c_3=25*(cantidad_int+1);
       c_4=35*(cantidad_int+1);
       c_5=22*cantidad_int;
       costo1=c_1+c_2+c_3+c_4+c_5; 
      cout<<"Se aplico el descuento del disfras del Fantasma"<<endl;
       cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(decimal_cantidad==0){
        descuento=20/4;
        c_1= (20-descuento)*cantidad_int;
        c_2=30*cantidad_int;
        c_3=25*cantidad_int;
        c_4=35*cantidad_int;
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"Se aplico el descuento del disfras del Fantasma"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
    }
    if(a==2){
      if(decimal_cantidad==1){
        descuento=30/4;
        c_1=20*(cantidad_int+1);
        c_2=(30-descuento)*cantidad_int;
        c_3=25*cantidad_int;
        c_4=35*cantidad_int;
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5; 
        cout<<"Se aplico el descuento del disfras de la Bruja"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(decimal_cantidad==2){
        descuento=30/4;
        c_1=20*(cantidad_int+1);
        c_2=(30-descuento)*(cantidad_int+1);
        c_3=25*cantidad_int;
        c_4=35*cantidad_int;
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5; 
        cout<<"Se aplico el descuento del disfras de la Bruja"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(decimal_cantidad==3){
        descuento=30/4;
        c_1=20*(cantidad_int+1);
        c_2=(30-descuento)*(cantidad_int+1);
        c_3=25*(cantidad_int+1);
        c_4=35*cantidad_int;
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5; 
        cout<<"Se aplico el descuento del disfras de la Bruja"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(decimal_cantidad==4){
        descuento=30/4;
        c_1=20*(cantidad_int+1);
        c_2=(30-descuento)*(cantidad_int+1);
        c_3=25*(cantidad_int+1);
        c_4=35*(cantidad_int+1);
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5; 
        cout<<"Se aplico el descuento del disfras de la Bruja"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(decimal_cantidad==0){
        descuento=30/4;
        c_1=20*cantidad_int;
        c_2=(30-descuento)*cantidad_int;
        c_3=25*cantidad_int;
        c_4=35*cantidad_int;
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;  
        cout<<"Se aplico el descuento del disfras de la Bruja"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
    }
    if(a==3){
      if(decimal_cantidad==1){
        descuento=25/4;
        c_1=20*(cantidad_int+1);
        c_2=30*cantidad_int;
        c_3=(25-descuento)*cantidad_int;
        c_4=35*cantidad_int;
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"Se aplico el descuento del disfras de Frankenstein"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(decimal_cantidad==2){
        descuento=25/4;
        c_1=20*(cantidad_int+1);
        c_2=30*(cantidad_int+1);
        c_3=(25-descuento)*cantidad_int;
        c_4=35*cantidad_int;
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"Se aplico el descuento del disfras de Frankenstein"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(decimal_cantidad==3){
        descuento=25/4;
        c_1=20*(cantidad_int+1);
        c_2=30*(cantidad_int+1);
        c_3=(25-descuento)*(cantidad_int+1);
        c_4=35*cantidad_int;
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"Se aplico el descuento del disfras de Frankenstein"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(decimal_cantidad==4){
        descuento=25/4;
        c_1=20*(cantidad_int+1);
        c_2=30*(cantidad_int+1);
        c_3=(25-descuento)*(cantidad_int+1);
        c_4=35*(cantidad_int+1);
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"Se aplico el descuento del disfras de Frankenstein"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(decimal_cantidad==0){
        descuento=25/4;
        c_1=20*cantidad_int;
        c_2=30*cantidad_int;
        c_3=(25-descuento)*cantidad_int;
        c_4=35*cantidad_int;
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"Se aplico el descuento del disfras de Frankenstein"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
    }
    if(a==4){
      if(decimal_cantidad==1){
        descuento=35/4;
        c_1=20*(cantidad_int+1);
        c_2=30*cantidad_int;
        c_3=25*cantidad_int;
        c_4=(35-descuento)*cantidad_int;
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"Se aplico el descuento del disfras del Esqueleto Bailador"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(decimal_cantidad==2){
        c_1=20*(cantidad_int+1);
        c_2=30*(cantidad_int+1);
        c_3=25*cantidad_int;
        c_4=(35-descuento)*cantidad_int;
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"Se aplico el descuento del disfras del Esqueleto Bailador"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(decimal_cantidad==3){
        c_1=20*(cantidad_int+1);
        c_2=30*(cantidad_int+1);
        c_3=25*(cantidad_int+1);
        c_4=(35-descuento)*cantidad_int;
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"Se aplico el descuento del disfras del Esqueleto Bailador"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(decimal_cantidad==4){
        c_1=20*(cantidad_int+1);
        c_2=30*(cantidad_int+1);
        c_3=25*(cantidad_int+1);
        c_4=(35-descuento)*(cantidad_int+1);
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"Se aplico el descuento del disfras del Esqueleto Bailador"<<endl;
       cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(decimal_cantidad==0){
        descuento=35/4;
        c_1=20*cantidad_int;
        c_2=30*cantidad_int;
        c_3=25*cantidad_int;
        c_4=(35-descuento)*cantidad_int;
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"Se aplico el descuento del disfras del Esqueleto Bailador"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
    }
    if(a==5){
      if(decimal_cantidad==1){
        descuento=22/4;
        c_1=20*(cantidad_int+1);
        c_2=30*cantidad_int;
        c_3=25*cantidad_int;
        c_4=35*cantidad_int;
        c_5=(22-descuento)*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"Se aplico el descuento del disfras del Zombie"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(decimal_cantidad==2){
        descuento=22/4;
        c_1=20*(cantidad_int+1);
        c_2=30*(cantidad_int+1);
        c_3=25*cantidad_int;
        c_4=35*cantidad_int;
        c_5=(22-descuento)*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"Se aplico el descuento del disfras del Zombie"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(decimal_cantidad==3){
        descuento=22/4;
        c_1=20*(cantidad_int+1);
        c_2=30*(cantidad_int+1);
        c_3=25*(cantidad_int+1);
        c_4=35*cantidad_int;
        c_5=(22-descuento)*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"Se aplico el descuento del disfras del Zombie"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(decimal_cantidad==4){
        descuento=22/4;
        c_1=20*(cantidad_int+1);
        c_2=30*(cantidad_int+1);
        c_3=25*(cantidad_int+1);
        c_4=35*(cantidad_int+1);
        c_5=(22-descuento)*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"Se aplico el descuento del disfras del Zombie"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(decimal_cantidad==0){
        descuento=22/4;
        c_1=20*cantidad_int;
        c_2=30*cantidad_int;
        c_3=25*cantidad_int;
        c_4=35*cantidad_int;
        c_5=(22-descuento)*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"Se aplico el descuento del disfras del Zombie"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
    }
  }
  if(antiguo==2){
    if(decimal_cantidad==1){
        c_1=20*(cantidad_int+1);
        c_2=30*cantidad_int;
        c_3=25*cantidad_int;
        c_4=35*cantidad_int;
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;  
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(decimal_cantidad==2){
        c_1=20*(cantidad_int+1);
        c_2=30*(cantidad_int+1);
        c_3=25*cantidad_int;
        c_4=35*cantidad_int;
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;  
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(decimal_cantidad==3){
        c_1=20*(cantidad_int+1);
        c_2=30*(cantidad_int+1);
        c_3=25*(cantidad_int+1);
        c_4=35*cantidad_int;
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(decimal_cantidad==4){
       descuento=20/4;
        c_1=20*(cantidad_int+1);
        c_2=30*(cantidad_int+1);
        c_3=25*(cantidad_int+1);
        c_4=35*(cantidad_int+1);
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5; 
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(decimal_cantidad==0){
        c_1=20*cantidad_int;
        c_2=30*cantidad_int;
        c_3=25*cantidad_int;
        c_4=35*cantidad_int;
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5; 
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
  }

  cout<<endl;
  cout<<"Finalmente sobran estos disfrases: "<<endl;
  if(decimal_cantidad==1){
    cout<<"- "<<(fantasma-(cantidad_int+1))<<" disfraces de Fantasma"<<endl;
    cout<<"- "<<(bruja-(cantidad_int))<<" disfraces de Bruja"<<endl;
    cout<<"- "<<(frankenstein-(cantidad_int))<<" disfraces de Frankenstein"<<endl;
    cout<<"- "<<(esqueleto_bailador-(cantidad_int))<<" disfraces de Esqueleto Bailador"<<endl;
    cout<<"- "<<(zombie-(cantidad_int))<<" disfraces de Zombie"<<endl;
  }
  if(decimal_cantidad==2){
    cout<<"- "<<(fantasma-(cantidad_int+1))<<" disfraces de Fantasma"<<endl;
    cout<<"- "<<(bruja-(cantidad_int+1))<<" disfraces de Bruja"<<endl;
    cout<<"- "<<(frankenstein-(cantidad_int))<<" disfraces de Frankenstein"<<endl;
    cout<<"- "<<(esqueleto_bailador-(cantidad_int))<<" disfraces de Esqueleto Bailador"<<endl;
    cout<<"- "<<(zombie-(cantidad_int))<<" disfraces de Zombie"<<endl;
  }
  if(decimal_cantidad==3){
    cout<<"- "<<(fantasma-(cantidad_int+1))<<" disfraces de Fantasma"<<endl;
    cout<<"- "<<(bruja-(cantidad_int+1))<<" disfraces de Bruja"<<endl;
    cout<<"- "<<(frankenstein-(cantidad_int+1))<<" disfraces de Frankenstein"<<endl;
    cout<<"- "<<(esqueleto_bailador-(cantidad_int))<<" disfraces de Esqueleto Bailador"<<endl;
    cout<<"- "<<(zombie-(cantidad_int))<<" disfraces de Zombie"<<endl;
  }
  if(decimal_cantidad==4){
    cout<<"- "<<(fantasma-(cantidad_int+1))<<" disfraces de Fantasma"<<endl;
    cout<<"- "<<(bruja-(cantidad_int+1))<<" disfraces de Bruja"<<endl;
    cout<<"- "<<(frankenstein-(cantidad_int+1))<<" disfraces de Frankenstein"<<endl;
    cout<<"- "<<(esqueleto_bailador-(cantidad_int+1))<<" disfraces de Esqueleto Bailador"<<endl;
    cout<<"- "<<(zombie-(cantidad_int))<<" disfraces de Zombie"<<endl;
  }
  if(decimal_cantidad==0){
    cout<<"- "<<(fantasma-(cantidad_int))<<" disfraces de Fantasma"<<endl;
    cout<<"- "<<(bruja-(cantidad_int))<<" disfraces de Bruja"<<endl;
    cout<<"- "<<(frankenstein-(cantidad_int))<<" disfraces de Frankenstein"<<endl;
    cout<<"- "<<(esqueleto_bailador-(cantidad_int))<<" disfraces de Esqueleto Bailador"<<endl;
    cout<<"- "<<(zombie-(cantidad_int))<<" disfraces de Zombie"<<endl;
  }
}
