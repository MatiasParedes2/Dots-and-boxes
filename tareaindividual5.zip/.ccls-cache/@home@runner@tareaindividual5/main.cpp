#include<iostream>
#include <iostream>
#include <stdlib.h>
#include "disfraces.h"
using namespace std;

int main() {
  int cantidad,si_no;
  bienvenida();
  costos();
  cout<<endl;
  cout<<"Indique la cantidad de su pedido: ";cin>>cantidad;
  do{
      cout<<"Es cliente antiguo [SI=1/NO=2]?";cin>>si_no;  
    if(si_no!=1 and si_no!=2){
      cout<<"Numero no valido"<<endl;
    }
  }while(si_no!=1 and si_no!=2);
  cout<<endl;
  Resultado resultado1(cantidad,si_no);
  resultado1.mostrar_resultado();
  return 0;
}

void bienvenida(){
  cout<<"BIENVENIDO A LA TIENDA DE DISFRACES"<<endl;
  cout<<"Hay 5 tipos de disfraces:"<<endl;
  cout<<"- 30 disfraces de Fantasma"<<endl;
  cout<<"- 40 disfraces de Bruja"<<endl;
  cout<<"- 20 disfraces de Frankenstein"<<endl;
  cout<<"- 50 disfraces de Esqueleto bailador"<<endl;
  cout<<"- 10 disfraces de Zombie"<<endl;
  cout<<"_🎉_🎉_🎉_🎉_🎉_🎉_🎉_🎉_🎉_🎉_🎉_"<<endl;
}
void costos(){
  cout<<"Costos de los 5 tipos de disfraces:"<<endl;
  cout<<"- 1 disfras de fantasma: S/20"<<endl;
  cout<<"- 1 disfras de Bruja: S/30"<<endl;
  cout<<"- 1 disfras de Frankenstein: S/25"<<endl;
  cout<<"- 1 disfras de Esqueleto bailador: S/35"<<endl;
  cout<<"- 1 disfras de Zombie: S/22"<<endl;
 }