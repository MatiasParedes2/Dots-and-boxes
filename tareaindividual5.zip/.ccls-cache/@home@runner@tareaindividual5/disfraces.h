#include<iostream>
#include<vector>
using namespace std;
void bienvenida();
void costos();

class Disfraces{
protected: 
  int cantidad;
  int fantasma=30;
  int bruja=40;
  int frankenstein=20;
  int esqueleto_bailador=50;
  int zombie=10;
  double cantidad_impar=cantidad%5;
  int cantidad_por_disfraz=cantidad/5;

public:
  Disfraces(int);
  void enseñar_cantidad_de_disfrases();
};

class Resultado : public Disfraces{
private:
  int miembro;
public:
  Resultado(int,int);
  void mostrar_resultado();
};

Disfraces::Disfraces(int _cantidad){
  cantidad=_cantidad;
}
Resultado::Resultado(int _cantidad, int _antiguo) : Disfraces(_cantidad){
  miembro=_antiguo;
}

void Disfraces::enseñar_cantidad_de_disfrases(){
  if(cantidad_impar==1){
    cout<<"Cantidad pedida por disfraz:"<<endl;
    cout<<"- "<<cantidad_por_disfraz<<" disfraces de Fantasma"<<endl;
    cout<<"- "<<cantidad_por_disfraz<<" disfraces de Bruja"<<endl;
    cout<<"- "<<cantidad_por_disfraz+1<<" disfraces de Frankenstein"<<endl;
    cout<<"- "<<cantidad_por_disfraz<<" disfraces de Esqueleto Bailador"<<endl;
    cout<<"- "<<cantidad_por_disfraz<<" disfraces de Zombie"<<endl;
  }
  if(cantidad_impar==2){
    cout<<"Cantidad pedida por disfraz:"<<endl;
    cout<<"- "<<cantidad_por_disfraz+1<<" disfraces de Fantasma"<<endl;
    cout<<"- "<<cantidad_por_disfraz<<" disfraces de Bruja"<<endl;
    cout<<"- "<<cantidad_por_disfraz<<" disfraces de Frankenstein"<<endl;
    cout<<"- "<<cantidad_por_disfraz+1<<" disfraces de Esqueleto Bailador"<<endl;
    cout<<"- "<<cantidad_por_disfraz<<" disfraces de Zombie"<<endl;
  }
  if(cantidad_impar==3){
    cout<<"Cantidad pedida por disfraz:"<<endl;
    cout<<"- "<<cantidad_por_disfraz+1<<" disfraces de Fantasma"<<endl;
    cout<<"- "<<cantidad_por_disfraz<<" disfraces de Bruja"<<endl;
    cout<<"- "<<cantidad_por_disfraz+1<<" disfraces de Frankenstein"<<endl;
    cout<<"- "<<cantidad_por_disfraz<<" disfraces de Esqueleto Bailador"<<endl;
    cout<<"- "<<cantidad_por_disfraz+1<<" disfraces de Zombie"<<endl;
  }
  if(cantidad_impar==4){
    cout<<"Cantidad pedida por disfraz:"<<endl;
    cout<<"- "<<cantidad_por_disfraz+1<<" disfraces de Fantasma"<<endl;
    cout<<"- "<<cantidad_por_disfraz+1<<" disfraces de Bruja"<<endl;
    cout<<"- "<<cantidad_por_disfraz<<" disfraces de Frankenstein"<<endl;
    cout<<"- "<<cantidad_por_disfraz+1<<" disfraces de Esqueleto Bailador"<<endl;
    cout<<"- "<<cantidad_por_disfraz+1<<" disfraces de Zombie"<<endl;  
  }
  if(cantidad_impar==0){
    cout<<"Cantidad pedida por disfraz:"<<endl;
    cout<<"- "<<cantidad_por_disfraz<<" disfraces de Fantasma"<<endl;
    cout<<"- "<<cantidad_por_disfraz<<" disfraces de Bruja"<<endl;
    cout<<"- "<<cantidad_por_disfraz<<" disfraces de Frankenstein"<<endl;
    cout<<"- "<<cantidad_por_disfraz<<" disfraces de Esqueleto Bailador"<<endl;
    cout<<"- "<<cantidad_por_disfraz <<" disfraces de Zombie"<<endl;
  }
}

void Resultado::mostrar_resultado(){
  enseñar_cantidad_de_disfrases();
  srand(time(NULL));
  int a=1+rand()%5;
  
  float costo1=0,c_1=cantidad_por_disfraz,c_2=cantidad_por_disfraz,c_3=cantidad_por_disfraz,c_4=cantidad_por_disfraz,c_5=cantidad_por_disfraz,descuento=0;
  
  if(miembro==1){
    if(a==1){
      if(cantidad_impar==1||cantidad_impar==2||cantidad_impar==3||cantidad_impar==4||cantidad_impar==0){
        descuento=20/4;
        c_1= (30-descuento)*(c_1+1);
        c_2=50*c_2;
        c_3=15*c_3;
        c_4=27*c_4;
        c_5=33*c_5;
        costo1=c_1+c_2+c_3+c_4+c_5;  
        cout<<"Se aplico el descuento del disfras del Fantasma"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
    }
    if(a==2){
      if(cantidad_impar==1||cantidad_impar==2||cantidad_impar==3||cantidad_impar==4||cantidad_impar==0){
        descuento=30/4;
        c_1=30*(c_1+1);
        c_2=(50-descuento)*c_2;
        c_3=15*c_3;
        c_4=27*c_4;
        c_5=33*c_5;
        costo1=c_1+c_2+c_3+c_4+c_5; 
        cout<<"Se aplico el descuento del disfras de la Bruja"<<endl;
        cout<<"El costo total a pagar sera de: S/"<<costo1<<endl;
      }
    }
    if(a==3){
      if(cantidad_impar==1||cantidad_impar==2||cantidad_impar==3||cantidad_impar==4||cantidad_impar==0){
        descuento=25/4;
        c_1=30*(c_1+1);
        c_2=50*c_2;
        c_3=(15-descuento)*c_3;
        c_4=27*c_4;
        c_5=33*c_5;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"Se aplico el descuento del disfras de Frankenstein"<<endl;
        cout<<"El costo total a pagar sera de: S/"<<costo1<<endl;
      }
      if(cantidad_impar==2){
        descuento=25/4;
        c_1=30*(cantidad_int+1);
        c_2=30*(cantidad_int+1);
        c_3=(25-descuento)*cantidad_int;
        c_4=35*cantidad_int;
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"Se aplico el descuento del disfras de Frankenstein"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(cantidad_impar==3){
        descuento=25/4;
        c_1=30*(cantidad_int+1);
        c_2=30*(cantidad_int+1);
        c_3=(25-descuento)*(cantidad_int+1);
        c_4=35*cantidad_int;
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"Se aplico el descuento del disfras de Frankenstein"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(cantidad_impar==4){
        descuento=25/4;
        c_1=30*(cantidad_int+1);
        c_2=30*(cantidad_int+1);
        c_3=(25-descuento)*(cantidad_int+1);
        c_4=35*(cantidad_int+1);
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"Se aplico el descuento del disfras de Frankenstein"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(cantidad_impar==0){
        descuento=25/4;
        c_1=30*cantidad_int;
        c_2=30*cantidad_int;
        c_3=(25-descuento)*cantidad_int;
        c_4=35*cantidad_int;
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"Se aplico el descuento del disfras de Frankenstein"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
    }
    if(a==4){
      if(cantidad_impar==1){
        descuento=35/4;
        c_1=30*(cantidad_int+1);
        c_2=30*cantidad_int;
        c_3=25*cantidad_int;
        c_4=(35-descuento)*cantidad_int;
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"Se aplico el descuento del disfras del Esqueleto Bailador"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(cantidad_impar==2){
        c_1=20*(cantidad_int+1);
        c_2=30*(cantidad_int+1);
        c_3=25*cantidad_int;
        c_4=(35-descuento)*cantidad_int;
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"Se aplico el descuento del disfras del Esqueleto Bailador"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(cantidad_impar==3){
        c_1=30*(cantidad_int+1);
        c_2=30*(cantidad_int+1);
        c_3=25*(cantidad_int+1);
        c_4=(35-descuento)*cantidad_int;
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"Se aplico el descuento del disfras del Esqueleto Bailador"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(cantidad_impar==4){
        c_1=30*(cantidad_int+1);
        c_2=30*(cantidad_int+1);
        c_3=25*(cantidad_int+1);
        c_4=(35-descuento)*(cantidad_int+1);
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"Se aplico el descuento del disfras del Esqueleto Bailador"<<endl;
       cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(cantidad_impar==0){
        descuento=35/4;
        c_1=30*cantidad_int;
        c_2=30*cantidad_int;
        c_3=25*cantidad_int;
        c_4=(35-descuento)*cantidad_int;
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"Se aplico el descuento del disfras del Esqueleto Bailador"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
    }
    if(a==5){
      if(cantidad_impar==1){
        descuento=22/4;
        c_1=20*(cantidad_int+1);
        c_2=30*cantidad_int;
        c_3=25*cantidad_int;
        c_4=35*cantidad_int;
        c_5=(22-descuento)*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"Se aplico el descuento del disfras del Zombie"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(cantidad_impar==2){
        descuento=22/4;
        c_1=20*(cantidad_int+1);
        c_2=30*(cantidad_int+1);
        c_3=25*cantidad_int;
        c_4=35*cantidad_int;
        c_5=(22-descuento)*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"Se aplico el descuento del disfras del Zombie"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(cantidad_impar==3){
        descuento=22/4;
        c_1=20*(cantidad_int+1);
        c_2=30*(cantidad_int+1);
        c_3=25*(cantidad_int+1);
        c_4=35*cantidad_int;
        c_5=(22-descuento)*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"Se aplico el descuento del disfras del Zombie"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(cantidad_impar==4){
        descuento=22/4;
        c_1=20*(cantidad_int+1);
        c_2=30*(cantidad_int+1);
        c_3=25*(cantidad_int+1);
        c_4=35*(cantidad_int+1);
        c_5=(22-descuento)*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"Se aplico el descuento del disfras del Zombie"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(cantidad_impar==0){
        descuento=22/4;
        c_1=20*cantidad_int;
        c_2=30*cantidad_int;
        c_3=25*cantidad_int;
        c_4=35*cantidad_int;
        c_5=(22-descuento)*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"Se aplico el descuento del disfras del Zombie"<<endl;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
    }
  }
  if(miembro==2){
    if(cantidad_impar==1){
        c_1=20*(cantidad_int+1);
        c_2=30*cantidad_int;
        c_3=25*cantidad_int;
        c_4=35*cantidad_int;
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;  
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(cantidad_impar==2){
        c_1=20*(cantidad_int+1);
        c_2=30*(cantidad_int+1);
        c_3=25*cantidad_int;
        c_4=35*cantidad_int;
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;  
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(cantidad_impar==3){
        c_1=20*(cantidad_int+1);
        c_2=30*(cantidad_int+1);
        c_3=25*(cantidad_int+1);
        c_4=35*cantidad_int;
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5;
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(cantidad_impar==4){
       descuento=20/4;
        c_1=20*(cantidad_int+1);
        c_2=30*(cantidad_int+1);
        c_3=25*(cantidad_int+1);
        c_4=35*(cantidad_int+1);
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5; 
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
      if(cantidad_impar==0){
        c_1=20*cantidad_int;
        c_2=30*cantidad_int;
        c_3=25*cantidad_int;
        c_4=35*cantidad_int;
        c_5=22*cantidad_int;
        costo1=c_1+c_2+c_3+c_4+c_5; 
        cout<<"El costo a pagar sera de: S/"<<costo1<<endl;
      }
  }

  cout<<endl;
  cout<<"Stock final: "<<endl;
  if(cantidad_impar==1){
    cout<<"- "<<(fantasma-(cantidad_int+1))<<" disfraces de Fantasma"<<endl;
    cout<<"- "<<(bruja-(cantidad_int))<<" disfraces de Bruja"<<endl;
    cout<<"- "<<(frankenstein-(cantidad_int))<<" disfraces de Frankenstein"<<endl;
    cout<<"- "<<(esqueleto_bailador-(cantidad_int))<<" disfraces de Esqueleto Bailador"<<endl;
    cout<<"- "<<(zombie-(cantidad_int))<<" disfraces de Zombie"<<endl;
  }
  if(cantidad_impar==2){
    cout<<"- "<<(fantasma-(cantidad_int+1))<<" disfraces de Fantasma"<<endl;
    cout<<"- "<<(bruja-(cantidad_int+1))<<" disfraces de Bruja"<<endl;
    cout<<"- "<<(frankenstein-(cantidad_int))<<" disfraces de Frankenstein"<<endl;
    cout<<"- "<<(esqueleto_bailador-(cantidad_int))<<" disfraces de Esqueleto Bailador"<<endl;
    cout<<"- "<<(zombie-(cantidad_int))<<" disfraces de Zombie"<<endl;
  }
  if(cantidad_impar==3){
    cout<<"- "<<(fantasma-(cantidad_int+1))<<" disfraces de Fantasma"<<endl;
    cout<<"- "<<(bruja-(cantidad_int+1))<<" disfraces de Bruja"<<endl;
    cout<<"- "<<(frankenstein-(cantidad_int+1))<<" disfraces de Frankenstein"<<endl;
    cout<<"- "<<(esqueleto_bailador-(cantidad_int))<<" disfraces de Esqueleto Bailador"<<endl;
    cout<<"- "<<(zombie-(cantidad_int))<<" disfraces de Zombie"<<endl;
  }
  if(cantidad_impar==4){
    cout<<"- "<<(fantasma-(cantidad_int+1))<<" disfraces de Fantasma"<<endl;
    cout<<"- "<<(bruja-(cantidad_int+1))<<" disfraces de Bruja"<<endl;
    cout<<"- "<<(frankenstein-(cantidad_int+1))<<" disfraces de Frankenstein"<<endl;
    cout<<"- "<<(esqueleto_bailador-(cantidad_int+1))<<" disfraces de Esqueleto Bailador"<<endl;
    cout<<"- "<<(zombie-(cantidad_int))<<" disfraces de Zombie"<<endl;
  }
  if(cantidad_impar==0){
    cout<<"- "<<(fantasma-(cantidad_int))<<" disfraces de Fantasma"<<endl;
    cout<<"- "<<(bruja-(cantidad_int))<<" disfraces de Bruja"<<endl;
    cout<<"- "<<(frankenstein-(cantidad_int))<<" disfraces de Frankenstein"<<endl;
    cout<<"- "<<(esqueleto_bailador-(cantidad_int))<<" disfraces de Esqueleto Bailador"<<endl;
    cout<<"- "<<(zombie-(cantidad_int))<<" disfraces de Zombie"<<endl;
  }
}