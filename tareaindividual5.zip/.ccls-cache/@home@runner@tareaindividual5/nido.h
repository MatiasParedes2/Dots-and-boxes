#include<iostream>
#include<vector>
using namespace std;

class jorge{
string nombre;
string codigo;
public:
    Clase(){codigo="";nombre="";}
    Clase(string _codigo,string _nombre):codigo(_codigo),nombre(_nombre){}
    string get_codigo(){return codigo;}
    string get_nombre(){return nombre;}
    void printData() {
        cout << codigo << ' ' << nombre;
    }
    ~Clase(){}
};