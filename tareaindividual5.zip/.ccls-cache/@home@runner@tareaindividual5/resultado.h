
#include<iostream>
#include "disfraces.h"
#include<vector>
using namespace std;

class Resultado : public Disfraces{
private:
  int antiguo;
public:
  Resultado(int,int);
  void mostrar_resultado();
};

Disfraces::Disfraces(int _cantidad){
  cantidad=_cantidad;
}
Resultado::Resultado(int _cantidad, int _antiguo) : Disfraces(_cantidad){
  antiguo=_antiguo;
}