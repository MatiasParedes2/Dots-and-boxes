#include<iostream>
#include <iostream>
#include <stdlib.h>
#include "disfraces.h"
using namespace std;
//nota el progama considera que va a comprar sin acabar el stock de uno de los tipos de disfraces
int main() {
  int cantidad,opcion;
  cout<<"Hola usuario, deseas comprar disfraces para este halloween?"<<endl;
  cout<<"Indique cuantos disfracez va a comprar: ";cin>>cantidad;
  do{
      cout<<"Es cliente antiguo?, tenemos beneficios para clientes antiguos"<<endl<<"Escriba 1 si es cliente antiguo, Escriba 2 si es cliente nuevo: ";cin>>opcion;  
    if(opcion!=1 and opcion!=2){
      cout<<"Numero no valido"<<endl;
    }
  }while(opcion!=1 and opcion!=2);
  cout<<endl;
  Resultado nido_abigail(cantidad,opcion);
  nido_abigail.mostrar_resultado();
  return 0;
}

void bienvenida(){
  cout<<"Tienda de disfraces abierta"<<endl;
  cout<<"Tenemos los siguientes disfrazes:"<<endl;
  cout<<"* 30 disfraces de Fantasma"<<endl;
  cout<<"* 40 disfraces de Bruja"<<endl;
  cout<<"* 20 disfraces de Frankenstein"<<endl;
  cout<<"* 50 disfraces de Esqueleto bailador"<<endl;
  cout<<"* 10 disfraces de Zombie"<<endl;
  cout<<""<<endl;
}
void precios(){
  cout<<"Costo por cada disfraz:"<<endl;
  cout<<"* 1 disfraz de fantasma: S/30"<<endl;
  cout<<"* 1 disfraz de Bruja: S/50"<<endl;
  cout<<"* 1 disfraz de Frankenstein: S/15"<<endl;
  cout<<"* 1 disfraz de Esqueleto bailador: S/27"<<endl;
  cout<<"* 1 disfraz de Zombie: S/33"<<endl;
 }